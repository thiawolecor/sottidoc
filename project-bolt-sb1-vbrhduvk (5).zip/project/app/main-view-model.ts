import { Observable, ImageSource } from '@nativescript/core';
import { Camera, requestPermissions } from '@nativescript/camera';
import { Imagepicker } from '@nativescript/imagepicker';
import { OpenCV } from '@nativescript/opencv';

export class MainViewModel extends Observable {
    private _previewImage: ImageSource;
    private _isProcessing: boolean = false;
    private _processingMessage: string = '';
    private opencv: OpenCV;

    constructor() {
        super();
        this.requestPermissions();
        this.initOpenCV();
    }

    private async initOpenCV() {
        try {
            this.opencv = new OpenCV();
            await this.opencv.init();
        } catch (err) {
            console.error('OpenCV initialization error:', err);
        }
    }

    get previewImage(): ImageSource {
        return this._previewImage;
    }

    set previewImage(value: ImageSource) {
        if (this._previewImage !== value) {
            this._previewImage = value;
            this.notifyPropertyChange('previewImage', value);
        }
    }

    get isProcessing(): boolean {
        return this._isProcessing;
    }

    set isProcessing(value: boolean) {
        if (this._isProcessing !== value) {
            this._isProcessing = value;
            this.notifyPropertyChange('isProcessing', value);
        }
    }

    get processingMessage(): string {
        return this._processingMessage;
    }

    set processingMessage(value: string) {
        if (this._processingMessage !== value) {
            this._processingMessage = value;
            this.notifyPropertyChange('processingMessage', value);
        }
    }

    async requestPermissions() {
        try {
            await requestPermissions();
        } catch (err) {
            console.error('Failed to get permissions', err);
        }
    }

    async onCameraTap() {
        try {
            this.isProcessing = true;
            this.processingMessage = 'Opening camera...';

            const image = await Camera.takePicture({
                width: 1920,
                height: 1080,
                keepAspectRatio: true,
                saveToGallery: false
            });

            this.processingMessage = 'Processing image...';
            const processedImage = await this.processDocument(image);
            this.previewImage = processedImage;
        } catch (err) {
            console.error('Camera error:', err);
        } finally {
            this.isProcessing = false;
            this.processingMessage = '';
        }
    }

    async onGalleryTap() {
        try {
            this.isProcessing = true;
            this.processingMessage = 'Opening gallery...';

            const imagepicker = new Imagepicker();
            const selection = await imagepicker.authorize();
            
            if (selection) {
                const imageAsset = await imagepicker.present();
                if (imageAsset && imageAsset[0]) {
                    const image = await ImageSource.fromAsset(imageAsset[0]);
                    this.processingMessage = 'Processing image...';
                    const processedImage = await this.processDocument(image);
                    this.previewImage = processedImage;
                }
            }
        } catch (err) {
            console.error('Gallery error:', err);
        } finally {
            this.isProcessing = false;
            this.processingMessage = '';
        }
    }

    private async processDocument(image: ImageSource): Promise<ImageSource> {
        try {
            // Convert to grayscale
            const gray = await this.opencv.cvtColor(image, this.opencv.COLOR_BGR2GRAY);
            
            // Apply Gaussian blur to reduce noise
            const blurred = await this.opencv.GaussianBlur(gray, { width: 5, height: 5 }, 0);
            
            // Edge detection using Canny
            const edges = await this.opencv.Canny(blurred, 75, 200);
            
            // Find contours
            const contours = await this.opencv.findContours(edges, this.opencv.RETR_EXTERNAL, this.opencv.CHAIN_APPROX_SIMPLE);
            
            // Find the largest contour (assumed to be the document)
            let maxArea = 0;
            let documentContour = null;
            
            for (const contour of contours) {
                const area = await this.opencv.contourArea(contour);
                if (area > maxArea) {
                    maxArea = area;
                    documentContour = contour;
                }
            }
            
            if (documentContour) {
                // Approximate the contour to get a rectangle
                const epsilon = 0.02 * await this.opencv.arcLength(documentContour, true);
                const approx = await this.opencv.approxPolyDP(documentContour, epsilon, true);
                
                // Draw the contour on the original image
                const result = await this.opencv.drawContours(image, [approx], -1, { red: 0, green: 255, blue: 0 }, 3);
                
                return result;
            }
            
            return image;
        } catch (err) {
            console.error('Document processing error:', err);
            return image;
        }
    }
}