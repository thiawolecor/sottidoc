import cv from '@techstark/opencv-js';
import { jsPDF } from 'jspdf';

let isOpenCVLoaded = false;

// Function to load OpenCV
async function loadOpenCV(): Promise<void> {
  return new Promise((resolve, reject) => {
    if (isOpenCVLoaded) {
      resolve();
      return;
    }

    // Use the already imported OpenCV.js from @techstark/opencv-js
    if (cv) {
      isOpenCVLoaded = true;
      resolve();
    } else {
      reject(new Error('Failed to load OpenCV.js'));
    }
  });
}

// Initialize OpenCV
let openCVPromise = loadOpenCV();

interface FilterOptions {
  brightness: number;
  contrast: number;
  sharpen: boolean;
  grayscale: boolean;
  autoEnhance: boolean;
  perspective: boolean;
  denoise: boolean;
  ocr: boolean;
  colorBalance: {
    red: number;
    green: number;
    blue: number;
  };
  gamma: number;
  saturation: number;
  shadows: number;
  highlights: number;
  blur: number;
  edgeEnhancement: boolean;
  documentMode: 'auto' | 'receipt' | 'document' | 'whiteboard' | 'photo';
}

const defaultOptions: FilterOptions = {
  brightness: 0,
  contrast: 0,
  sharpen: false,
  grayscale: false,
  autoEnhance: true,
  perspective: true,
  denoise: true,
  ocr: false,
  colorBalance: { red: 1, green: 1, blue: 1 },
  gamma: 1,
  saturation: 1,
  shadows: 0,
  highlights: 0,
  blur: 0,
  edgeEnhancement: false,
  documentMode: 'auto'
};

export async function processImage(
  imageData: ImageData, 
  options: Partial<FilterOptions> = {}
): Promise<ImageData> {
  await openCVPromise;
  
  const opts = { ...defaultOptions, ...options };
  const src = cv.matFromImageData(imageData);
  let dst = new cv.Mat();
  
  try {
    // Initial color conversion
    if (opts.grayscale) {
      cv.cvtColor(src, dst, cv.COLOR_RGBA2GRAY);
      cv.cvtColor(dst, dst, cv.COLOR_GRAY2RGBA);
    } else {
      src.copyTo(dst);
    }

    // Apply document-specific optimizations
    if (opts.documentMode !== 'auto') {
      switch (opts.documentMode) {
        case 'receipt':
          // Optimize for receipts - high contrast, enhanced text
          opts.contrast = 40;
          opts.sharpen = true;
          opts.edgeEnhancement = true;
          opts.grayscale = true;
          break;
        case 'document':
          // Optimize for documents - balanced enhancement
          opts.autoEnhance = true;
          opts.denoise = true;
          opts.edgeEnhancement = true;
          break;
        case 'whiteboard':
          // Optimize for whiteboards - color correction, noise reduction
          opts.colorBalance = { red: 1.1, green: 1.1, blue: 1.1 };
          opts.contrast = 20;
          opts.denoise = true;
          break;
        case 'photo':
          // Optimize for photos - color preservation, detail enhancement
          opts.saturation = 1.2;
          opts.denoise = true;
          opts.edgeEnhancement = true;
          break;
      }
    }

    // Advanced color correction
    if (!opts.grayscale) {
      // Split channels
      let channels = new cv.MatVector();
      cv.split(dst, channels);
      
      // Apply color balance
      for (let i = 0; i < 3; i++) {
        const balance = [opts.colorBalance.red, opts.colorBalance.green, opts.colorBalance.blue][i];
        channels.get(i).convertTo(channels.get(i), -1, balance);
      }
      
      // Merge channels back
      cv.merge(channels, dst);
      channels.delete();
    }

    // Gamma correction
    if (opts.gamma !== 1) {
      let lookUpTable = new Uint8Array(256);
      for (let i = 0; i < 256; i++) {
        lookUpTable[i] = Math.min(255, Math.pow(i / 255, 1 / opts.gamma) * 255);
      }
      let lutMat = cv.matFromArray(256, 1, cv.CV_8U, lookUpTable);
      cv.LUT(dst, lutMat, dst);
      lutMat.delete();
    }

    // Denoise
    if (opts.denoise) {
      // Use bilateral filter instead of fastNlMeansDenoisingColored
      if (opts.documentMode === 'receipt' || opts.documentMode === 'document') {
        // Stronger denoising for documents
        cv.bilateralFilter(dst, dst, 9, 75, 75);
      } else {
        // Gentler denoising for photos
        cv.bilateralFilter(dst, dst, 5, 50, 50);
      }
    }

    // Adaptive contrast enhancement
    if (opts.autoEnhance) {
      let lab = new cv.Mat();
      cv.cvtColor(dst, lab, cv.COLOR_RGB2Lab);
      let channels = new cv.MatVector();
      cv.split(lab, channels);
      
      // Enhanced CLAHE with adaptive parameters
      let clahe = new cv.CLAHE(
        opts.documentMode === 'receipt' ? 4.0 : 3.0,
        new cv.Size(8, 8)
      );
      clahe.apply(channels.get(0), channels.get(0));
      
      cv.merge(channels, lab);
      cv.cvtColor(lab, dst, cv.COLOR_Lab2RGB);
      
      channels.delete();
      lab.delete();
      clahe.delete();
    }

    // Shadows and highlights recovery
    if (opts.shadows !== 0 || opts.highlights !== 0) {
      let hsv = new cv.Mat();
      cv.cvtColor(dst, hsv, cv.COLOR_RGB2HSV);
      let channels = new cv.MatVector();
      cv.split(hsv, channels);
      
      // Adjust V channel for shadows and highlights
      let v = channels.get(2);
      if (opts.shadows > 0) {
        cv.multiply(v, new cv.Mat(v.rows, v.cols, v.type(), [1 + opts.shadows]), v);
      }
      if (opts.highlights < 0) {
        let highlights = new cv.Mat();
        cv.subtract(new cv.Mat(v.rows, v.cols, v.type(), [255]), v, highlights);
        cv.multiply(highlights, new cv.Mat(v.rows, v.cols, v.type(), [1 - opts.highlights]), highlights);
        cv.subtract(new cv.Mat(v.rows, v.cols, v.type(), [255]), highlights, v);
        highlights.delete();
      }
      
      cv.merge(channels, hsv);
      cv.cvtColor(hsv, dst, cv.COLOR_HSV2RGB);
      
      channels.delete();
      hsv.delete();
    }

    // Edge enhancement
    if (opts.edgeEnhancement) {
      let edges = new cv.Mat();
      let gray = new cv.Mat();
      cv.cvtColor(dst, gray, cv.COLOR_RGBA2GRAY);
      cv.Canny(gray, edges, 50, 150);
      cv.cvtColor(edges, edges, cv.COLOR_GRAY2RGBA);
      cv.addWeighted(dst, 1, edges, 0.2, 0, dst);
      edges.delete();
      gray.delete();
    }

    // Perspective correction with improved corner detection
    if (opts.perspective) {
      let gray = new cv.Mat();
      cv.cvtColor(dst, gray, cv.COLOR_RGBA2GRAY);
      cv.GaussianBlur(gray, gray, new cv.Size(5, 5), 0);
      
      // Multi-scale edge detection
      let edges = new cv.Mat();
      cv.Canny(gray, edges, 75, 200);
      
      // Improved contour detection
      let contours = new cv.MatVector();
      let hierarchy = new cv.Mat();
      cv.findContours(edges, contours, hierarchy, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE);
      
      // Find the largest contour with proper aspect ratio
      let maxArea = 0;
      let maxContourIndex = -1;
      
      for (let i = 0; i < contours.size(); i++) {
        const area = cv.contourArea(contours.get(i));
        if (area > maxArea) {
          const rect = cv.boundingRect(contours.get(i));
          const aspectRatio = rect.width / rect.height;
          // Check if aspect ratio is reasonable for a document
          if (aspectRatio > 0.5 && aspectRatio < 2.0) {
            maxArea = area;
            maxContourIndex = i;
          }
        }
      }
      
      if (maxContourIndex !== -1) {
        const epsilon = 0.02 * cv.arcLength(contours.get(maxContourIndex), true);
        const approx = new cv.Mat();
        cv.approxPolyDP(contours.get(maxContourIndex), approx, epsilon, true);
        
        if (approx.rows === 4) {
          // Improved corner sorting
          const corners = [];
          for (let i = 0; i < 4; i++) {
            corners.push({
              x: approx.data32S[i * 2],
              y: approx.data32S[i * 2 + 1],
              sum: approx.data32S[i * 2] + approx.data32S[i * 2 + 1]
            });
          }
          
          // Sort corners using sum of coordinates
          corners.sort((a, b) => a.sum - b.sum);
          
          // Determine corners more accurately
          const tl = corners[0];
          const br = corners[3];
          const tr = corners[1].x > corners[2].x ? corners[1] : corners[2];
          const bl = corners[1].x < corners[2].x ? corners[1] : corners[2];
          
          let srcTri = cv.matFromArray(4, 1, cv.CV_32FC2, [
            tl.x, tl.y, tr.x, tr.y,
            br.x, br.y, bl.x, bl.y
          ]);
          
          // Calculate output size maintaining aspect ratio
          const width = Math.max(
            Math.hypot(tr.x - tl.x, tr.y - tl.y),
            Math.hypot(br.x - bl.x, br.y - bl.y)
          );
          const height = Math.max(
            Math.hypot(bl.x - tl.x, bl.y - tl.y),
            Math.hypot(br.x - tr.x, br.y - tr.y)
          );
          
          let dstTri = cv.matFromArray(4, 1, cv.CV_32FC2, [
            0, 0, width - 1, 0,
            width - 1, height - 1, 0, height - 1
          ]);
          
          let M = cv.getPerspectiveTransform(srcTri, dstTri);
          let warped = new cv.Mat();
          cv.warpPerspective(dst, warped, M, new cv.Size(width, height));
          
          warped.copyTo(dst);
          
          srcTri.delete();
          dstTri.delete();
          M.delete();
          warped.delete();
        }
        
        approx.delete();
      }
      
      gray.delete();
      edges.delete();
      contours.delete();
      hierarchy.delete();
    }

    // Final adjustments
    if (opts.brightness !== 0 || opts.contrast !== 0) {
      dst.convertTo(dst, -1, 1 + opts.contrast / 100, opts.brightness);
    }

    if (opts.sharpen) {
      let kernel = cv.Mat.ones(3, 3, cv.CV_32F);
      kernel.data32F[4] = 9;
      cv.filter2D(dst, dst, -1, kernel);
      kernel.delete();
    }

    if (opts.blur > 0) {
      cv.GaussianBlur(dst, dst, new cv.Size(opts.blur * 2 + 1, opts.blur * 2 + 1), 0);
    }

    // Convert back to ImageData
    const result = new ImageData(
      new Uint8ClampedArray(dst.data),
      dst.cols,
      dst.rows
    );
    
    return result;
  } finally {
    src.delete();
    dst.delete();
  }
}

export async function applyFilter(
  imageData: ImageData,
  filterType: 'original' | 'grayscale' | 'enhance' | 'blackAndWhite' | 'color' | 'document' | 'receipt' | 'whiteboard' | 'photo'
): Promise<ImageData> {
  const options: Partial<FilterOptions> = {
    brightness: 0,
    contrast: 0,
    sharpen: false,
    grayscale: false,
    autoEnhance: false,
    perspective: false,
    denoise: false,
    ocr: false,
    documentMode: 'auto'
  };

  switch (filterType) {
    case 'grayscale':
      options.grayscale = true;
      break;
    case 'enhance':
      options.autoEnhance = true;
      options.sharpen = true;
      options.contrast = 10;
      options.denoise = true;
      options.edgeEnhancement = true;
      break;
    case 'blackAndWhite':
      options.grayscale = true;
      options.contrast = 50;
      options.brightness = 10;
      options.edgeEnhancement = true;
      break;
    case 'color':
      options.autoEnhance = true;
      options.sharpen = true;
      options.contrast = 15;
      options.brightness = 5;
      options.denoise = true;
      options.saturation = 1.2;
      break;
    case 'document':
      options.documentMode = 'document';
      break;
    case 'receipt':
      options.documentMode = 'receipt';
      break;
    case 'whiteboard':
      options.documentMode = 'whiteboard';
      break;
    case 'photo':
      options.documentMode = 'photo';
      break;
    default:
      break;
  }

  return processImage(imageData, options);
}

export async function generatePDF(images: string[], options: {
  pageSize?: 'a4' | 'letter' | 'legal',
  orientation?: 'portrait' | 'landscape',
  quality?: 'high' | 'medium' | 'low',
  margin?: number,
  compression?: boolean,
  metadata?: {
    title?: string;
    author?: string;
    subject?: string;
    keywords?: string;
  }
} = {}): Promise<Blob> {
  const {
    pageSize = 'a4',
    orientation = 'portrait',
    quality = 'high',
    margin = 10,
    compression = true,
    metadata = {}
  } = options;
  
  const doc = new jsPDF({
    orientation,
    unit: 'mm',
    format: pageSize,
    compress: compression
  });

  // Set document metadata
  if (metadata.title) doc.setProperties({ title: metadata.title });
  if (metadata.author) doc.setProperties({ author: metadata.author });
  if (metadata.subject) doc.setProperties({ subject: metadata.subject });
  if (metadata.keywords) doc.setProperties({ keywords: metadata.keywords });

  const compressionQuality = quality === 'high' ? 0.95 : quality === 'medium' ? 0.8 : 0.6;
  
  for (let i = 0; i < images.length; i++) {
    if (i > 0) {
      doc.addPage();
    }

    const pageWidth = orientation === 'portrait' ? 210 : 297;
    const pageHeight = orientation === 'portrait' ? 297 : 210;
    
    const imageWidth = pageWidth - (margin * 2);
    const imageHeight = pageHeight - (margin * 2);

    doc.addImage(
      images[i],
      'JPEG',
      margin,
      margin,
      imageWidth,
      imageHeight,
      undefined,
      'FAST',
      compressionQuality
    );
  }
  
  return doc.output('blob');
}

export async function batchProcess(
  images: ImageData[],
  options: Partial<FilterOptions>
): Promise<ImageData[]> {
  return Promise.all(images.map(img => processImage(img, options)));
}