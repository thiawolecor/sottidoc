// Update the auth state effect in App.tsx
useEffect(() => {
  supabase.auth.getSession().then(({ data: { session } }) => {
    setUser(session?.user ?? null);
    if (!session) {
      // Clear any cached data when no session exists
      localStorage.removeItem('supabase.auth.token');
    }
  });

  const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
    setUser(session?.user ?? null);
    if (event === 'SIGNED_OUT' || event === 'TOKEN_REFRESHED') {
      // Handle auth state changes
      setError(null);
      setScannerState(prev => ({
        ...prev,
        documents: [],
        currentImage: null,
        isProcessing: false
      }));
    }
  });

  return () => {
    subscription.unsubscribe();
  };
}, []);